# When frontier scores stay high

Use this path when Astra/Opus still solves the task or a prior hardening attempt did not help. It extends the source-to-output loop in SKILL.md; it is not a catalog of proven frontier weaknesses.

## Reconstruct what was actually tested

Keep a compact experiment record in the task conversation:

| Version / target model | Proposed decision change | Actual saved change and source locations | Matching runs and output locations | Result / next action |
|---|---|---|---|---|

Compare actual before/after files when available, not just the advice. Distinguish a proposed edit, an expert-reported edit, and a verified edit. If old files or the earlier Codex exchange are missing, say the causal chain is incomplete; continue from the current task. Do not require retrieval of hidden Realm versions or assume the expert ignored the advice. If several things changed together, do not attribute a score change to one of them.

Read a strong complete attempt from each high-scoring target model first, then check the other available attempts and all linked deliverables. Preserve per-model denominators and coverage limits. Build a short **already solved** list: calculations, source reconciliation, scheduling, contingencies, authorization and trade-offs the model actually handles. Inspect relevant tool calls and results to establish its method: an optimizer, query, script or recalculated workbook may solve a whole family of proposed edits. Read archived code as evidence; do not execute it. Haiku misses do not establish an Astra or Opus weakness. The historical library's interval error, for example, was absent in all three inspected Astra attempts.

Classify the evidence before choosing a direction:

- **Genuine success:** the output solves the professional decisions. Explain why the available facts make the solution tractable; design a new source-grounded decision if the situation supports one.
- **Credit for a material error:** locate the error across the complete output and its scoring check. This is a grading concern, even at 100%; fixing credit does not prove new task difficulty.
- **Low score from execution or missing input:** diagnose separately. More work is not justified by an incomplete attempt's low score.
- **Evidence missing:** provide a bounded design hypothesis, not an explanation of observed model reasoning. A score screenshot cannot distinguish these cases.

These can coexist within a run; classify individual findings rather than forcing all scores into one cause.

## Design from the successful solution

When the model is correct, establish what made the task tractable. It may be a dominant option, independent calculations, a rule that selects the answer, source text that supplies the recommendation, or genuine coupled reasoning that the model successfully formalizes and solves. Verify this in the sources, output and trajectory; do not assume reconciliation or calculation is inherently easy. Keep legitimate tool use available; restricting it solely to force lower scores does not strengthen the professional assignment.

Separate **discovering what matters**, **formalizing its meaning and scope**, and **executing the calculation or plan**. Locate the part the proposed revision actually challenges. A source can supply essential business rules without doing the solver's reasoning; an author-created branch map or explanation may already supply that reasoning. Do not remove useful standards, dates or deliverable requirements merely because they are clear. For concrete comparisons involving irreversible transformations, historical obligations, different operational paths, exception scope and measurement bases, read [comparative-designs.md](comparative-designs.md). Distinguish source-derived observations from failures in matching runs, especially when successful-task archives contain only Golden answers.

Check for **complexity lost during task preparation** before adding new challenges. With available originals or the expert's unpolished account, compare the solver-facing version for pre-resolved contradictions, merged evidence, omitted exceptions, removed competing routes and added explanations of dependencies. Record `original relationship → preparation change → reasoning no longer required → proposed restoration`. Restoring an authentic interaction can be a substantive experiment even when it adds no new business fact. Do not infer that AI cleaned the task merely because a model scored highly.

Illustrative authoring comparison, not a fact about any current task: an operations email says a unit is ready, an inspection record leaves a prerequisite unresolved, and an approval log limits authorization to an earlier configuration. Replacing those records with “restart is blocked pending inspection and approval” gives away the reconciliation. Preserve the distinct records, their dates and scopes, and ask for the professional readiness decision. Conversely, adding random contradictions without a defensible decision route is not restoration. For an unknown approval outcome, a justified conditional plan may be correct; the rubric must not demand invented certainty.

Consider a few candidate changes privately, reject those already handled by the strongest output, and present the best supported one. Change a consequential relationship within the professional assignment, not the number of requested explanations. Depending on the task, this might mean a shared resource coupling two decisions, an uncertain prerequisite that changes the executable plan, or a feasible option whose downstream cost changes the recommendation. A real trade-off need not have a unique winner; defensible alternatives must remain creditable.

For each candidate you keep, work through:

1. **Actual choice:** identify the options, the controlling source facts and the professional consequence. Calculate their relevant costs, timing, resource use or risks yourself. Identify infeasible or dominated routes in the private analysis; preserve plausible proposals in source records when evaluating and rejecting them is part of the solver's work. If one route is mechanically selected by an unchanged rule, explain what new reasoning is really being added. Do not claim difficulty merely because two options are named.
2. **Interaction:** show where an apparently sensible local choice changes another obligation. For allocation tasks, account for what happens to the deprioritized work; for recovery tasks, carry both sequences through completion and verification. Simply asking for more justification does not create an interaction.
3. **Change boundary:** state exactly what source record, requirement and affected answer/rubric would change. One experiment can include coordinated edits to several files and interacting constraints. Preserve existing complexity; do not minimize the number of decisions or prune realistic context as a default. Add or restore records when they contribute meaningful synthesis or judgment, rather than volume alone. Removing answer leakage is different from hiding necessary definitions, rules or facts. Source/rubric alignment must preserve intentional disagreements between business records and grade their resolution fairly.
4. **Evidence boundary:** cite existing facts. If a new domain fact is needed, identify the smallest missing fact and why it changes the choice. Proposed scenario wording must be explicitly labeled for expert verification, never passed off as an existing source fact. Do not invent constraints solely to make a good solution fail.

If the sources do not support a meaningful new choice, give the expert a precise source-design question rather than polishing the same checklist again. For example: which existing resource is genuinely shared, what is the consequence of allocating it to either option, and where is that documented? Do the arithmetic and document joining once that fact is available.

## Check the proposed change before spending another run

Perform a **worked preflight**, not a prediction of model scores:

- Solve the proposed case using only the proposed model-facing facts. Show at least one executable, professionally defensible route and the fate of its material obligations. Keep this private authoring analysis out of solver-facing sources.
- Compare the proposed solver-facing package with the baseline for **accidental simplification**: joined evidence, resolved conflicts, exposed decisive dependencies, removed plausible routes, erased uncertainty or an outcome request expanded into a solution checklist. Preserve or strengthen the intended reasoning in the sources; do not leak the authoring solution through more explicit instructions. Explain the distinction between your clear advice to the expert and the complex evidence left to the solver.
- Replay the strongest old answer's **method**, not just its literal numbers. If changing an input, extending the same optimization model or rerunning the same query handles the candidate, or the output already supplies the comparison, reject it as the next frontier experiment unless another consequential judgment is demonstrated. Restoring problem-discovery work can be tested separately even if the old solver handles the reconstructed problem; label that limited hypothesis accurately. Conversely, a wrong answer to newly changed facts is not proof the model will repeat it.
- Check a plausible alternative solution, including conditional approval, a different valid sequence, or a safe deferral when allowed. The rubric must credit valid routes and distinguish the material error without mandating the author's wording. Verify changed numerical targets, ranges and assumptions jointly; an unchanged Golden or cached judge rationale may be stale.
- Explain the **assessment reach**: which existing important decisions and checks this change can affect, and which high-value work remains routine. Count one underlying omission once in the behavioral diagnosis. If the change touches only a minor check, call it a limited experiment. Do not increase weights, duplicate penalties or extrapolate a hypothetical score to promise the gate will pass.

Package the first experiment in a compact form: **baseline and target → one source/decision change → worked valid route and alternative → why the old method may be insufficient → aligned files/checks → observable result that confirms or rejects the hypothesis**. Supply precise replacement wording where supported; mark unresolved domain facts. A missing decisive fact makes it a conditional design, not a ready-to-apply fix.

## Read the next output and decide

After the expert saves the change, check the new version's requirements in Realm and the current instructions. Follow the required gate order; do not bypass Haiku to run a locked model. An exploratory result is not a substitute for the required scored-run set, and this skill does not launch runs.

Compare the intended decision in the new target-model output, not only the average:

- A completed attempt makes the predicted material error: record it as observed once, or repeated only if the evidence supports that label; check fairness and other valid answers.
- The target model solves the revised choice: record the candidate as **handled in the inspected runs** and retire it for the next experiment. Preserve useful realistic content, but do not keep amplifying the same mechanism with wording, extra rows or harsher checks.
- The score changes because the rubric changed, outputs are incomplete, or sources/version differ: report the confound rather than declaring reasoning success.

If repeated attempts still show genuine frontier success and no candidate survives preflight, explain that incremental edits have reached a limit. Give the HDL and expert a concrete design brief: already-solved decisions, rejected candidates, the professionally meaningful source relationship needed, and the minimum missing evidence. Propose a deeper revision within the same assignment for expert judgment; do not silently rewrite the whole task, guarantee a threshold, or keep generating cosmetic edits.
