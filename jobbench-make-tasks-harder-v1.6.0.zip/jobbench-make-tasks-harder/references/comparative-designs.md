# Learn from solved and signed-off tasks

Read this when repeated frontier success calls for a structural revision, or when successful expert tasks are supplied as comparisons. These examples guide investigation; they are not a menu of proven Astra/Opus weaknesses. Transfer the professional relationship, not the example's domain or wording.

## What the October 29 evidence establishes

The supplied Task 253 export contains one complete GPT-6 Astra attempt, `a4242d64-7929-4378-953a-bc1cd6335852`, reward 1.0, on task digest `7d50b8fa068686a21f9a9fe68ebac0ced9b10c0a674dd4c65c7c3ec193599f56`. Its actual user prompt matches the exported instructions. No Opus attempt or five-run mean is established. A separate export contains Tasks 269, 271, 272 and 276, supplied as signed-off examples, but its manifest has **zero runs**. Their source relationships below are verified design observations, not explanations of observed low scores. Golden files are not model attempts. Numeric Realm versions and the earlier two skill conversations were not supplied by these exports.

### 253: coupled scheduling can already be tractable

The current Line 2 Bay 4 task has five named cases, scarce macro-inspection slots, dated authority, customer approval clocks, stock dispositions, next-day cut availability, shared cutting capacity and external purchasing. Do not tell its author to add these as though they were absent.

The strongest supplied attempt derives release gates, then calls `scipy.optimize.milp` to allocate cuts, production, inventory and shortages. It compares 0/150/180 purchased kits, produces linked workbooks and recalculates them. In the normal-delivery/extraction-absent case, six packs reduce uncovered pieces from 225 to 210; in the late-delivery/extraction-absent case, five packs achieve 660 and a sixth saves no shortage. The absence recovery case yields 780. Independent ledger checks support the submitted conservation, cutting capacity and dispatch arithmetic, conditional on the output's gate dates; this is not an exhaustive certification or proof of global optimality.

Locators: charter §§12–14; asset register `Blank stock` and `Production parameters`; email thread's AB-2810 and FS-28 records; output `Shutdown_and_Restart_Schedule.xlsx`, `Materials`, `Dispatch`, `Case comparison`; `Restart_Decision_Memo.docx`, purchasing comparison. In raw `stirrup_history.json`, outer list element 0, zero-based messages 26–27 contain the optimization tool call/result; message 54 records recalculation checks.

**Design consequence:** inspect the method used to construct the solution as well as the answer. More dates, allocations or cases may only add variables to a working formulation. Keep useful source complexity, but identify the additional judgment the proposed change demands before calling it stronger. Tool use is legitimate task performance; do not prohibit tools just to lower scores. One successful attempt is evidence against an unqualified weakness claim, not proof that every later attempt will succeed.

## Source relationships worth investigating

### 276 — preserving meaning across an irreversible change

`M41_Migration_Spec.docx` §1.1 maps both status codes 4 and 7 to `held`; §3.1 drops the original code. `Controls_Register.xlsx`, Controls row 2 and Notes rows 2–3, requires historical FIN-07 packs as well as a new reporting basis. `Data_Change_Standard_DCS-2.docx` §§2.4 and 2.8 requires reproducible historical evidence and forbids restating reported categories. A migration can satisfy the new schema while destroying information needed to reproduce old obligations. Reversing `held` cannot recover which old code was reported.

There is a second path distinction: the snapshot replay in M41 §2.2 covers only `app_rw`, while `job_catalogue.csv` has ERA-02 running as `privacy_rw`. The design must consider writes outside the assumed replay path. This is a substantive data-migration requirement, not an instruction to redact an expert's task materials.

**Transfer:** look for a locally correct transformation that loses evidence or changes meaning for another consumer, period or responsibility. The useful authoring question is what must remain reproducible after the proposed fix, and which records establish it. Preserve the original proposal, control and consumer records separately. Do not insert the conclusion “this loses historical codes” into solver-facing instructions. A feasible answer may preserve an appropriate historical representation while changing the live schema; merely renaming columns or restoring a whole backup does not demonstrate that all obligations survive.

### 272 — a control does not cover every path or time

`Marrowind_Onboarding_Notes.pdf` §§3–4 says object lock applies only after enablement and bulk history import bypasses collector processors. `change_log_2026-09_to_11.xlsx`, CR-3100 and CR-3104, starts cutover at 22:00 on November 21 but enables lock at 01:00 on November 22. `Cutover_Thread_2026-10.docx`, October 27 14:40, records older request bodies in `http.body`; `collector_configs_2026-10-30.txt` identifies the mask's fields. A correct live route or current source-code fix does not by itself protect historical imports or earlier writes. CR-2215 also changes payout-scheduler's behavior on January 12, after cutover.

**Transfer:** follow the actual path of the object being protected: live versus imported, before versus after enablement, and present versus approved future state. Look for a gap that changes the action, not simply another deadline. A workable plan must handle the uncovered interval or path and verify that handling. Keep enough operational evidence to support a solution; do not use unexplained missing data as the challenge.

### 269 — an exception's scope can differ from a rule's scope

`Alert_Routing_Standard_ARS-1-2.docx` §2.5 exempts conditions caused by one customer's configuration on that customer's endpoint. `Ops_Thread_2026-10.docx` records Kestrel, Dunlin and Heron incidents. `alert_rules_export_2026-10-25.csv`, AR-173/178/179, represents wider enabled rules. A customer-specific incident does not establish that every event the rule detects deserves the same treatment.

Separately, the proposed payments rota starts November 16, but `oncall_rotas_2026-10-26.xlsx`, Notes A3, gives home cover a 15-minute acknowledgement target. More calendar coverage does not automatically supply the required response capability.

**Transfer:** preserve distinctions between an individual event and a population, a component and a service path, availability and capability, or permission and its named scope. The task should require a usable operating decision. Do not replace the source-specific incidents with a summary that already labels the correct rule treatment.

### 271 — equal labels can conceal different measurement bases

The supplied 2018 annual report's consolidated income statement (PDF page 125, printed 123) marks 2017 as restated; its segment note (PDF page 140, printed 138) changes the continuing-operation perimeter. The 2022 report (PDF page 166, printed 164) distinguishes reported net debt from the lease-excluding, exchange-rate-adjusted covenant basis. The 2024 income statement (PDF page 163, printed 161) shows adjusted/statutory operating profit of £472.1m/£391.0m, while continuing profit after tax is £309.6m/£315.4m. The adjustment's direction cannot simply be copied between measures.

**Transfer:** require a professionally defensible comparison across revisions, definitions or populations. Formulas may be easy once the correct inputs are chosen; input meaning and comparability remain part of the work. Preserve the original statements and notes instead of providing a pre-normalized dataset. Missing annual-report filenames do not establish that every metric for that year is absent: check later comparative disclosures metric by metric.

## Turn a comparison into a concrete experiment

Start with the target task's sources and the strongest available model method. Find a comparable relationship only if the professional situation supports it. Write the author's proposal as:

`specific source relationship → locally plausible answer → consequential obligation it misses → exact source/outcome edits → worked valid route and alternative → next-run observation`.

For example, “add a historical obligation” is too generic. Identify which record must survive, who later needs it, what the current action destroys, when preservation must occur, and what evidence the solver will receive. Draft those records or the outcome requirement for expert verification. Keep the reconciled explanation and correct plan in the authoring conversation.

Differentiate two experiments:

- **Restore discovery work:** remove a pre-solved branch table or explanatory conclusion while preserving every underlying fact, timing, scope and required outcome in credible records. This tests whether the model can reconstruct the problem. It does not establish that its optimizer will fail once it has reconstructed it. Changing where a fact lives alone is weak evidence of increased difficulty; identify the inference formerly supplied.
- **Strengthen the professional decision:** add or restore an authentic interaction that changes what constitutes a valid solution, such as preserving historical evidence before an irreversible transformation. Work through feasibility and plausible alternatives. If the only difference is another input to the old formulation, explain why the candidate adds meaningful reasoning or retire it.

Do not combine these silently: if both change together, a score difference cannot isolate their effects. Keep clear standards, professional terminology, necessary facts and usable deliverable requirements. Real complexity does not require obscure wording. Signed-off status alone validates neither a particular mechanism nor every rubric detail; matching target-model outputs are needed to learn what actually failed.
