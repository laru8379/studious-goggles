# Independently checked failure mechanisms

This is a small, qualified evidence library. It is not a list of weaknesses every model has. The October 23 audit read the latest original sources for Bhopal's tasks **256, 258 and 264**. That TAR exported **zero model runs**. Behavioral evidence below comes from seven previously supplied **264 v27** runs, after comparing the current task with the earlier review package. The sources, normalized instructions and effective rubric match. The historical runs are not new trials on the latest export.

One recurring mechanism survived a conservative source-to-output check. A related fallback pattern has repeated warning signs but is not admitted as a confirmed failure mode. Bhopal's other observations and new source-derived checks are in [candidate-checks.md](candidate-checks.md). They remain questions to investigate, not independently confirmed recurring failures. Read [evidence-notes.md](evidence-notes.md) for provenance and corrections to the original six claims.

## What qualifies as a mode

A mode is a **repeated, materially wrong decision produced by the same underlying shortcut**. A single error, a low score, a Golden answer, and several failed child criteria about the same mistake do not establish recurrence.

Before labeling a mode observed repeatedly:

1. Establish the required decision from the prompt and sources the solver actually received.
2. Identify the incompatible output in at least two distinct eligible attempts on the same task version. Two is a minimum observation threshold, not statistical proof.
3. Explain the common mechanism. Similar wording alone is not enough.
4. State the denominator and break counts down by **solver model**. The judge's model field is not the solver identity.
5. Read successful attempts and alternative solutions. Record what would disprove the diagnosis.
6. Exclude judge inconsistency, arbitrary evidence placement, valid shorthand, missing inputs and execution failures.

Use these labels accurately:

- **Repeated in this sample:** the mechanism recurred in distinct attempts, with scope and model counts stated.
- **Observed once:** a real error, without evidence of recurrence.
- **Author-reported:** an attributed observation whose underlying outputs have not been independently checked.
- **Source-derived hypothesis:** a real task relationship that might expose a weakness, with no behavioral evidence yet.
- **Grading concern:** a disagreement about scoring or an unsupported scoring requirement. Keep it outside the failure count.

Do not describe within-task repetition as cross-task replication. Do not infer frequency outside the inspected sample.

## 1. Checking the start date but not the full operating interval

**Mechanism:** The model checks that a change starts before expiry or a deadline. It fails to carry that constraint through the required recovery, overlap or verification period.

**Independent evidence, task 264:** KCS §9.2 requires a valid rollback at every point during the 72 hours after a payment-path change. §1.4 makes the expiry date the last valid day. The old Brightpay certificate expires on November 6. A bridge installed November 4 at 03:30 needs valid rollback through November 7 at 03:30. Keeping the old certificate cannot meet that obligation. A November 3 bridge ends its rollback window on November 6 and avoids this particular error.

The same mechanism appears when a plan offers a fallback change on the old object's last valid day. The replacement can go live that day, but the declared old-object rollback cannot remain valid for another 72 hours.

| Inspected output | Concrete problem |
|---|---|
| Fable `08c445fa`, plan table 1 row 2 | Bridge starts November 4. Required rollback extends beyond the old certificate's validity. |
| Opus `2e5db287`, plan table 1 row 6 | Bridge starts November 5, creating the same gap. |
| Fable `08c445fa` and `a3497828` | Key-05 fallback is November 12, its last valid day. Both also allow the ledger certificate fallback through its November 19 expiry. |

**Observed scope:** 3 of 7 runs, with six affected schedule entries. Fable 2/2, Opus 1/2, Astra 0/3. Count unique runs, not six independent model failures. The Astra attempts are useful counterexamples and do not support calling this an observed Astra weakness.

**How to investigate another task:** Build a timeline containing the primary action, prior-state validity, required overlap or recovery interval, dependencies, blackout periods and fallback dates. Compute the entire interval. Look for plans that satisfy each headline date separately but cannot satisfy them together.

**Expert change worth testing:** When the real work requires continuity, expose the relevant dates and dependencies in normal source records and ask for an executable schedule. Apply this only if the target model's outputs reveal the shortcut or the proposal is explicitly labeled an untested hypothesis. Do not copy a 72-hour rule into another field without a professional reason.

**False positives:** A different valid recovery configuration is supplied, an authorized exception covers the interval, or the rule does not apply to the object. Read the complete plan and cross-referenced register before deciding the fallback is invalid.

## A related candidate: constraints dropped in the fallback

**Mechanism:** The model correctly recognizes a prerequisite, then proposes a contingency that violates that prerequisite or another governing rule. Naming a fallback does not make it executable.

**Observed wording, task 264:** The normal mobile-certificate switch is gated on at least 90% app connectivity. In the failed-adoption branch:

- Fable `a3497828`, plan paragraph 10, offers an exception **or a freeze-period change**. The second option does not specify an exception covering the payment freeze prohibited by KCS §9.1.
- Opus `2e5db287`, plan table 2 row 2, offers an exception **or moving the certificate anyway** while adoption is below the §7.5 threshold.

These are concerning **proposed decision options**, not completed actions. Both appear in requests for a Security Lead decision, and the standard permits exceptions. The text does not specify a covering exception for the questionable option, but the author could intend to obtain one through that decision. Because an authorization-dependent interpretation remains possible, keep this as a candidate for clarification rather than a confirmed behavioral failure. Do not use it to inflate the confirmed count.

**Observed wording:** 2 of 7 runs, Fable 1/2, Opus 1/2, Astra 0/3. This counts the warning signs, not confirmed errors. Both runs also appear in the interval finding. The independently confirmed count remains three distinct runs.

**Counterexample:** Astra `37c18102` gives a conditional, named, dated exception with controls and explicitly blocks the route if approval is unresolved or refused. The issue is not that an exception was requested.

**How to investigate another task:** For each event-dependent plan, follow both branches. Reapply the original constraints to the failure branch, including approval, timing, availability and continuity. Check whether a deferred action has a feasible later window and whether “escalate” leaves a clearly safe interim state.

**Expert change worth testing:** If the professional situation genuinely depends on an uncertain event, require a workable contingency using the supplied facts. Allow a valid exception or staged route when the task's authority permits one. Do not demand an impossible unconditional guarantee.

**False positives:** The plan explicitly proposes changing a constraint through a valid approval process, supplies the necessary controls and dates, and prohibits execution until approval. Do not treat that as an unauthorized action.

## Applying the library

Do not require every task to contain these mechanisms. For each recommendation provide:

1. The **source fact and applicable rule**, with a precise location.
2. The **actual model output**, with run ID and location.
3. The **professional consequence** of the wrong decision.
4. The **evidence status**, denominator, solver-model breakdown and counterexamples.
5. The **expert-owned change** to consider and the next-run observation that would confirm or reject the hypothesis.

If the target model already handles a mechanism correctly, say so. A failure observed in Claude runs is not evidence that the same change will challenge GPT-6 Astra. Suggest another evidence-supported direction or clearly label an experiment. Never promise a score reduction.
