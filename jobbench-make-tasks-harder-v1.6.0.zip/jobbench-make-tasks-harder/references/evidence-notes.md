# Evidence provenance and limits

Audit date: October 23, 2026, America/Los_Angeles. The export's October 24 timestamp is UTC.

## Materials

- Authoritative task source: `jobbench-20261024-051742-f37f2330.tar`, export ID `f37f2330-59c3-41c5-a34d-27b5f4541792`. It contains task 256, Region failover readiness review, task 258, Pre-audit network drift check, and task 264, Certificate and key rotation review.
- Its README reports zero reference trials. `scores.json` reports zero runs for every task. Original task sources and Golden solutions do not establish model behavior.
- Supplemental behavioral source: `jobbench-task-264-v27-runs (1).zip`. Seven succeeded, scored solver runs with the three requested output files. Oracle is excluded.
- Version provenance: the supplied Realm screenshot associates these run IDs with version 27. `run.json` does not itself include the version. Current sources are byte-identical to the earlier 264 review package. Instructions match after removing wrapper headings. The effective rubric matches after excluding authoring-only source and justification fields. This supports use as historical corroborating evidence, not a claim of new trials on the latest export.
- No 258 or 256 run artifacts were available for independent behavioral validation.

## Solver runs

| Run ID | Solver | Reward |
|---|---|---|
| `08c445fa-d1dd-4a1b-aba4-2d524bb85939` | Claude Fable 5.1 | 33.9% |
| `a3497828-de4b-444f-a96b-fcb9d0ffd4b6` | Claude Fable 5.1 | 23.2% |
| `2e5db287-87c1-4a54-a169-3cca873bf09b` | Claude Opus 5.5 | 28.6% |
| `d19e1018-879a-4f32-b856-f2f50b74f61a` | Claude Opus 5.5 | 21.4% |
| `37c18102-cb61-471c-ac87-767566d87169` | GPT-6 Astra | 81.3% |
| `60ffe42d-970b-43dd-9bcf-f1d4343710dd` | GPT-6 Astra | 26.8% |
| `caa4ef98-2803-4c95-97b6-11c5a258ae3e` | GPT-6 Astra | 33.9% |

These rewards are recorded metadata, not independent quality judgments. Judge metadata identifies `openai/gpt-5.5`. Do not confuse that with the solver models above.

## Direct source-to-output checks

**Interval validity:** `Key_and_Certificate_Standard_KCS-1-4.docx` §§1.4, 9.2, `certificate_inventory_2026-10-20.csv` rows crt-06 and crt-12, `key_inventory_2026-10-20.csv` row key-05, and the payment-path shading and windows in `Certificate_Deployment_Map_v3.png` and `Change_Calendar_Nov2026.png`.

- crt-06 expires November 6 inclusive. November 4 at 03:30 + 72 hours = November 7 at 03:30. The old certificate is invalid for the last 3.5 hours. November 5 creates a 27.5-hour gap.
- key-05 expires November 12 inclusive. A November 12 at 22:00 fallback needs valid rollback until November 15 at 22:00, leaving 70 hours uncovered by the old key.
- crt-12 expires November 19 inclusive. A November 19 at 09:00 fallback needs valid rollback until November 22 at 09:00, leaving 57 hours uncovered by the old certificate.
- A November 3 at 03:30 bridge keeps the original certificate valid through the required November 6 at 03:30 endpoint. This is a feasible counterexample, not an arbitrary preferred date.

**Contingency validity:** KCS §§7.5, 9.1, 10.4 and 13.1. Fable `a3497828` plan paragraph 10 and Opus `2e5db287` plan table 2 row 2 offer the questionable alternatives described in the main library. They are proposed options in requests for a Lead decision, not completed actions. Because an exception-dependent interpretation remains possible, this is a candidate check rather than a confirmed failure mode. Astra `37c18102` paragraph 8 supplies a conditional exception and blocks an unresolved or refused route.

Table and paragraph numbers refer to an XML-order extraction of the original DOCX. They are evidence locators, not Word page numbers. Search the exact object ID and quoted text if a renderer numbers tables differently.

## Corrections to the earlier six-pattern presentation

- Author reports must retain attribution. A signed-off task and its Golden answer do not validate an empirical claim about model behavior.
- “Nine of twelve fails” is Bhopal's report. The underlying unit and count were not independently established.
- “Both readers” can correctly reference a register naming both readers. It is not inherently a contradiction.
- All seven inspected registers preserve MapCo's dated contract basis. A date missing from the plan does not mean the model missed it entirely.
- All seven inspected warehouse-loader registers select rotation and describe the pending/refused extension. That sample does not support “they requested again instead of fixing.”
- Missing explicit key-03 rubric branches require further interpretation. The outputs generally preserve uncertainty rather than guessing the key is current.
- Some judge decisions distinguish a named item-level verification from a global verification instruction. That can be a scoring interpretation issue. Do not count it as a genuine task failure without establishing the professional requirement and checking all outputs.

The independently checked recurring interval mechanism is limited to this seven-run sample. It did not appear in the three inspected Astra runs. The fallback wording remains a separate, unconfirmed candidate. There is no cross-task recurrence claim and no prediction that these mechanisms will lower a new task's Astra score.
