# Candidate checks that still need behavioral evidence

These checks preserve useful ideas without calling every idea a verified failure mode. The original six were primarily drawn from [Bhopal's account of tasks 258 and 264](https://micro1-experts.slack.com/archives/C0CB9QRRVK2/p1792600342189679). The latest three-task export verifies task structure, not failure frequency. Task 258 and 256 model outputs were absent from the material available for this audit.

Use each check only after reading the new expert's sources and actual model deliverables. A source-derived challenge becomes an observed recurring failure only when it meets the admission standard in [failure-modes.md](failure-modes.md).

## Similar cases with different decisions

**Status:** Author-reported on 258. Source relationships independently checked. Behavioral recurrence remains unverified.

258's two Kafka maintenance windows fall on different sides of the November 2 freeze. The ops thread also gives different readiness information for their consumers. A single disposition for both might miss a material difference. However, the source text explicitly confirms certificates for the API and worker tiers, not an explicit absence of a certificate for etl-01. Do not convert missing confirmation into a proven absence merely because the Golden or an author says so.

**Check:** Map each case to the fact that changes the decision, then inspect whether the model preserves that distinction. The same action can still be valid for two different cases if its dependencies are handled correctly.

**Transfer:** Two orders, assets, contracts or projects may look alike but require different treatment because one documented dependency or deadline differs. The distinction must be supplied and professionally meaningful.

## Correct action without executable follow-through

**Status:** Author-reported. The independently confirmed interval failure is described more precisely in the main library. Questionable contingency options remain unconfirmed, and other omissions need their own evidence.

Bhopal reported “nine of twelve fails” on 258. The unit and denominator cannot be verified from the current materials. Do not turn this into nine failed runs or a general failure rate.

**Check:** Trace prerequisite → affected party → change → timing → recovery → verification. Determine which links are required by this task. Then inspect all linked deliverables for the actual missing link.

**False-positive guard:** “Verify all clients” may be sufficient when the clients and procedure are clearly established elsewhere. It is not automatically sufficient when an important distinct client test is missing. Prove the lost dependency or unexecutable instruction instead of penalizing brevity. Evaluate global instructions consistently across runs.

## Planned or partially completed work treated as current state

**Status:** Author-reported on 258, with source-derived cases in all three tasks. The seven inspected 264 runs do not establish the claimed warehouse-extension error.

**Check:** Keep separate records for requested, approved, deployed, effective and verified state. Test the relevant object and date, not just the status label of a larger project.

- In 258, CR-0433 says deployed, but the ops thread says only the allocation and rule change landed. The host remains in its old subnet.
- In 256, CR-0612 is marked deployed while the DNS export still gives TTL 3600. A completed change record does not override the actual control value.
- In 264, all seven inspected registers choose warehouse-loader rotation and distinguish the pending extension from an accepted exception. A later conditional request is not evidence that the model assumed approval or abandoned the fix.

**Transfer:** Approval of a purchase is not receipt, a scheduled inspection is not a completed inspection, and a project completion label may not establish every component's state. Check source authority and scope rather than always choosing the newest-looking record.

## Missing information without a usable decision route

**Status:** Author-reported. 264 has repeated rubric failures for explicit key-03 branches, but that alone does not establish a repeated professional error.

The seven inspected runs mark the cryptoperiod unknown and ask for evidence or propose a remedial route. They do not simply assert it is current. Some do not spell out the rubric's exact two branches. Before treating that as a failure, determine whether the task requires those branches and whether the proposed alternative is sound.

**Check:** Identify the unresolved fact, who can establish it, the decision deadline and how materially different answers affect the plan. Distinguish guessing the answer, leaving an essential branch unresolved, and legitimately deferring a decision with a workable interim state.

**Transfer:** Ask for conditional actions when the professional situation needs them. Do not force branches that make no difference or add unsupported assumptions to complete a checklist.

## Inconsistency between linked deliverables

**Status:** Author-reported. The original “both readers” example is not sufficient evidence of contradiction.

**Check:** Join outputs using stable entity IDs. Compare actual owners, dates, scope, quantities, dispositions and actions. Recalculate summaries. Read document cross-references before calling an omission.

In Astra `37c18102`, the plan says “both readers” and the db/reporting register names report-svc and finance-export and requires a single coordinated reload. That is compatible. A genuine inconsistency would be rotating only one reader, assigning different dates or using a summary that excludes one without justification.

**Transfer:** A multi-file task is useful when different recipients need linked outputs. Extra files or repeated names are not difficulty mechanisms by themselves.

## A decision without its supporting evidence

**Status:** Author-reported. The broad claim that the inspected 264 answers contain no MapCo decision basis is not supported.

All seven inspected registers include the ended contract and dated evidence supporting revocation. Their plan entries do not all repeat the dates. The prompt explicitly puts conflict resolution in the register's evidence column, so missing duplication is not automatically missing reasoning.

**Check:** Locate the supporting record across the authorized deliverables. If a standalone approval document really requires its own evidence, establish that requirement from the task and evaluate whether the reference is usable. Do not invent a “repeat this date in this paragraph” rule to create failures.

**Transfer:** An unsupported action, a wrong citation and a correctly supported action with concise cross-referencing are three different cases.

## Additional relationships found independently in task 256

These are **source-derived hypotheses**, not confirmed model failure modes. No 256 model outputs were present.

- **A valid end state reached through a destructive transition.** RFS §10.6 and the ops thread require preserving active services. Re-seeding the cart database needs coordinated handling of production writes and canary writes. Simply reversing the replication arrow could reproduce the previously described data loss. Test the sequence and interim state, not just the final diagram.
- **Indirect dependencies outside the obvious component list.** The ops thread says canary-runner-c both writes test carts and tails the events mirror. It matters to two changes despite being absent from the approved architecture drawing. Build the dependency set from all relevant sources.
- **Approval and calendar constraints that must be worked backwards together.** Change requests are due Thursday for a Monday board. The mirror's next first-Thursday slot is November 5, making October 29 the submission cutoff for the November 2 board. A plan that only checks “before November 27” could miss that earlier gate. No model failure is claimed without outputs.
- **Repairing one layer while leaving the actual path broken.** The standby cart API uses port 9443 and `/ready`. Its target group and security group still use 8443, with no target health check. A nominal “enable health checks” fix must also use the applicable endpoint and permit its port. This is an end-to-end dependency check.
- **Removing something unwanted without preserving remaining obligations.** Settlement continues writing to settle-db-w until November 18, and auditors need its records in January. Stopping an undrawn replication link, retiring the service and retaining historical evidence are different decisions. Test whether a plan separates them.

These relationships enrich the diagnostic process. Do not advertise them as weaknesses that Bhopal's models exhibited until the relevant run artifacts are checked.
