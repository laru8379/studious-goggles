#!/usr/bin/env python3
"""Read-only inventory of JobBench ZIP packages and TAR task exports."""

import argparse
import json
import sys
import tarfile
import zipfile
from collections import Counter
from pathlib import Path


MAX_JSON_BYTES = 5_000_000


def inventory_tar(path):
    """Inspect metadata without extracting or executing archive contents."""
    with tarfile.open(path, "r:*") as archive:
        members = [m for m in archive.getmembers() if m.isfile()]
        names = [m.name for m in members]
        result = {"archive": str(path), "file_count": len(names), "kind": "task_export"}
        unsafe = [m.name for m in archive.getmembers()
                  if m.name.startswith("/") or ".." in Path(m.name).parts
                  or m.issym() or m.islnk()]
        if unsafe:
            result["unsafe_member_names"] = unsafe[:20]
        manifests = [m for m in members if Path(m.name).name == "export-manifest.json"]
        scores = [m for m in members if Path(m.name).name == "scores.json"]
        for label, candidates in [("manifest", manifests), ("scores", scores)]:
            if len(candidates) != 1:
                result[label + "_note"] = f"Expected one metadata file, found {len(candidates)}."
                continue
            member = candidates[0]
            if member.size > MAX_JSON_BYTES:
                result[label + "_note"] = "Metadata exceeds JSON inventory limit."
                continue
            with archive.extractfile(member) as stream:
                data = json.load(stream)
            if label == "manifest":
                result["export_id"] = data.get("export_id")
                result["manifest_run_count"] = len(data.get("runs", []))
            else:
                result["tasks"] = [{"task_id": t.get("realm_task_id"),
                                    "slug": t.get("slug"),
                                    "reported_run_count": t.get("n_runs")}
                                   for t in data.get("tasks", [])]
                result["reported_run_count"] = data.get("totals", {}).get("run_count")
        result["reference_files"] = [n for n in names if "/environment/assets/" in n]
        result["solution_files"] = [n for n in names if "/solution/" in n]
        result["run_metadata_files"] = [n for n in names if n.endswith("/run.json")]
        result["trial_result_files"] = [n for n in names
                                        if "/trials/" in n and n.endswith("/result.json")]
        result["evidence_note"] = (
            "Task sources and solution/Golden files do not establish model behavior. "
            "Inspect actual run deliverables before making recurrence claims."
        )
        if result.get("reported_run_count") == 0:
            result["next_input"] = (
                "This export reports zero runs. Add each task's matching Runs > "
                "Download all runs ZIP for behavioral analysis."
            )
        return result


def read_json(archive, name):
    try:
        item = archive.getinfo(name)
        if item.file_size > MAX_JSON_BYTES:
            return {"error": f"{name} exceeds JSON inventory limit"}
        return json.loads(archive.read(name))
    except (KeyError, ValueError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        return {"error": f"cannot read {name}: {exc}"}


def inventory(path):
    if tarfile.is_tarfile(path):
        return inventory_tar(path)
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        files = [n for n in names if not n.endswith("/")]
        result = {"archive": str(path), "file_count": len(files)}
        unsafe = [n for n in files if n.startswith("/") or ".." in Path(n).parts]
        if unsafe:
            result["unsafe_member_names"] = unsafe[:20]

        if "task.json" in files and "runs.json" in files:
            result["kind"] = "review_package"
            task = read_json(archive, "task.json")
            runs = read_json(archive, "runs.json")
            result["task_id"] = task.get("realm_task_id")
            result["task_status"] = task.get("status")
            result["task_updated"] = task.get("date_updated")
            result["current_task_version"] = runs.get("current_task_version")
            result["run_summary_complete"] = runs.get("complete")
            result["run_summary_reason"] = runs.get("reason")
            result["reference_files"] = [n for n in files if n.startswith("reference-files/")]
            result["golden_files"] = [n for n in files if n.startswith("golden-deliverables/")]
            result["has_prompt"] = "prompt.md" in files
            result["has_rubric"] = "rubric.json" in files or "rubric.md" in files
            result["run_rows"] = [
                {
                    "run_id": row.get("run_id"),
                    "model": row.get("model"),
                    "version": row.get("task_version"),
                    "type": row.get("run_type"),
                    "status": row.get("status"),
                    "score": row.get("score", row.get("reward")),
                    "withhold_sources": row.get("withhold_sources"),
                }
                for row in runs.get("runs", [])
                if isinstance(row, dict)
            ]
            result["original_model_outputs_in_archive"] = any(
                "/verifier/output__" in n or "/verifier/output.zip" in n for n in files
            )
            if not result["original_model_outputs_in_archive"]:
                result["next_input"] = "Add the matching Runs > Download all runs ZIP to inspect original outputs and trajectories."
        else:
            run_files = [n for n in files if n.endswith("/run.json")]
            if run_files:
                result["kind"] = "runs_export"
                run_rows = []
                for name in run_files:
                    row = read_json(archive, name)
                    prefix = name[: -len("run.json")]
                    members = [n for n in files if n.startswith(prefix)]
                    run_rows.append(
                        {
                            "folder": prefix.rstrip("/"),
                            "run_id": row.get("run_id"),
                            "model": row.get("model"),
                            "status": row.get("status"),
                            "score": row.get("reward"),
                            "task_version": row.get("task_version"),
                            "output_files": [n for n in members if "/verifier/output__" in n],
                            "has_output_zip": any(n.endswith("/verifier/output.zip") for n in members),
                            "has_agent_trajectory": any(n.endswith("/agent/trajectory.json") for n in members),
                        }
                    )
                result["runs"] = run_rows
                result["models"] = dict(Counter(x["model"] for x in run_rows))
                if any(x["task_version"] is None for x in run_rows):
                    result["version_note"] = "At least one run.json lacks task_version; match run IDs to Realm or a review package."
            else:
                result["kind"] = "other_zip"
                result["first_files"] = files[:30]
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archives", nargs="+", type=Path)
    args = parser.parse_args()
    results = []
    for path in args.archives:
        try:
            results.append(inventory(path))
        except (OSError, zipfile.BadZipFile, tarfile.TarError, ValueError) as exc:
            results.append({"archive": str(path), "error": str(exc)})
    json.dump(results, sys.stdout, indent=2, ensure_ascii=False)
    print()
    return int(any("error" in x for x in results))


if __name__ == "__main__":
    raise SystemExit(main())
